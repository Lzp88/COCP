#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

#define PI 3.14159265358979323846
#define DELTA1 0.01    // 固定步长
#define NUM_DIRECTIONS 100  // 随机方向数量
#define T_ITER 250         // 一维搜索迭代次数
#define K 50          // 总步数

// 定义目标函数 f(x, y, N)
double f(double x, double y, int N) {
    double term1 = -log(pow(x - 0.5, 2) + pow(y - 0.5, 2) + 0.00001);
    double term2 = -log(pow(x + 0.5, 2) + pow(y + 0.5, 2) + 0.01);
    double term3 = -log(pow(x - 0.5, 2) + pow(y + 0.5, 2) + 0.01);
    double term4 = -log(pow(x + 0.5, 2) + pow(y - 0.5, 2) + 0.01);
    return pow(fmax(0.0, term1 + term2 + term3 + term4), N);
}

// 生成随机单位方向 (v_x, v_y)
void generate_random_direction(double* v_x, double* v_y) {
    double theta = 2 * PI * ((double)rand() / RAND_MAX);
    *v_x = cos(theta);
    *v_y = sin(theta);
}

// 计算沿方向 v 的差值
double compute_difference(double x, double y, double v_x, double v_y, double r_t, int N) {
    double f_plus = f(x + r_t * v_x, y + r_t * v_y, N);
    double f_minus = f(x - r_t * v_x, y - r_t * v_y, N);
    return fabs(f_plus - f_minus);
}

// 沿方向 v 进行一维搜索，返回最优步长 s
double compute_s_along_v(double x, double y, double v_x, double v_y, int N, int T_iter, double DELTA) {
    double s_t = 0.0;
    double Int1 = 0.0, Int2 = 0.0, Int3 = 0.0, Int = 0.0;

    auto f_s = [&](double s) { return f(x + s * v_x, y + s * v_y, N); };

    for (int i = 1; i < T_iter; ++i) {
        double term1 = f_s(s_t - i * DELTA);
        double term2 = f_s(s_t + i * DELTA);
        if (term1 != 0.0) Int1 += DELTA * term1;
        if (term2 != 0.0) Int1 -= DELTA * term2;
    }

    for (int i = -10; i <= 10; ++i) {
        double si = i * DELTA / 10.0;
        Int2 += (i * DELTA * f_s(s_t + si)) / 100.0;
    }

    Int = Int1 - Int2;

    for (int t = 0; t <= T_iter; ++t) {
        double y = s_t;
        s_t -= DELTA * copysign(1.0, Int);

        Int1 = 0.0;
        for (int i = 1; i <= 10; ++i) {
            double si = s_t + DELTA + i * DELTA / 10.0;
            double yi = y - DELTA + i * DELTA / 10.0;
            Int1 += copysign(1.0, Int) * DELTA / 10.0 * f_s(si) +
                    copysign(1.0, Int) * DELTA / 10.0 * f_s(yi);
        }

        Int3 = Int2;
        Int2 = 0.0;
        for (int i = -10; i <= 10; ++i) {
            double shifted_s = s_t + i * DELTA / 10.0;
            Int2 += (i * DELTA * f_s(shifted_s)) / 100.0;
        }

        Int = Int - Int1 - Int2 + Int3;
    }

    return s_t;
}

// 单步更新 (x_t, y_t)
void update_x_y_t(double* x_t, double* y_t, double r_t, int N, int T_iter, double DELTA) {
    double max_diff = -1.0;
    double best_v_x = 0.0, best_v_y = 0.0;

    for (int i = 0; i < NUM_DIRECTIONS; ++i) {
        double v_x, v_y;
        generate_random_direction(&v_x, &v_y);
        double diff = compute_difference(*x_t, *y_t, v_x, v_y, r_t, N);
        if (diff > max_diff) {
            max_diff = diff;
            best_v_x = v_x;
            best_v_y = v_y;
        }
    }

    double s = compute_s_along_v(*x_t, *y_t, best_v_x, best_v_y, N, T_iter, DELTA);

    *x_t += s * best_v_x;
    *y_t += s * best_v_y;
}

// 主函数
int main() {
    srand(time(NULL));

    int N = 5;
    double x_t = -0.5;
    double y_t = -0.5;
    double r_t = 10*DELTA1;

    printf("Initial: x_t = %f, y_t = %f, r_t = %f\n", x_t, y_t, r_t);

    for (int t = 1; t <= K; ++t) {
        update_x_y_t(&x_t, &y_t, r_t, N, T_ITER, DELTA1);
        if (r_t<1) {r_t += 2*DELTA1;}
      else {r_t=1;}
        printf("Step %d: x_t = %f, y_t = %f, r_t = %f\n", t, x_t, y_t, r_t);
    }

    printf("Final value after %d steps: x_t = %f, y_t = %f, r_t = %f\n", K, x_t, y_t, r_t);

    return 0;
}
