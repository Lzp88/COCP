// Online C compiler to run C program online
#include <stdio.h>
#include <math.h>

// 定义二元函数指针类型
typedef double (*FuncPtr2)(double, double);

// 二元函数 f(x, y)
double custom_f(double x, double y) {
    double term1 = pow(x - 0.5, 2) + pow(y - 0.5, 2) + 0.00001;
    double term2 = pow(x + 0.5, 2) + pow(y + 0.5, 2) + 0.01;
    double expr = -log(term1) - log(term2);
    return fmax(0.0, pow(expr,5));
}

// 返回结果的结构体
typedef struct {
    double x;
    double y;
} Result;

// 单步更新函数：根据当前 t 的奇偶性更新 x 或 y
Result run_simulation_step(double x_prev, double y_prev, int T, double DELTA, FuncPtr2 f, int is_update_x) {
    double Int_val = 0.0;

    // 计算积分项（根据要更新的变量选择方向）
    if (is_update_x) {
        // 更新 x，y 保持不动
        double Int1 = 0.0, Int2 = 0.0;
        
        // Int1 计算（x 方向积分）
        for (int i = 1; i < T; ++i) {
            double term1 = f(x_prev - i*DELTA, y_prev);
            double term2 = f(x_prev + i*DELTA, y_prev);
            if (term1 != 0.0) Int1 += DELTA * term1;
            if (term2 != 0.0) Int1 -= DELTA * term2;
        }

        // Int2 计算（x 方向二阶项）
        for (int i = -10; i <= 10; ++i) {
            double xi = x_prev + i*DELTA/10.0;
            if (xi >= -0.2 && xi <= 1.6) {
                Int2 += (i * DELTA * f(xi, y_prev)) / 100.0;
            }
        }

        Int_val = Int1 - Int2;
        x_prev -= DELTA * copysign(1.0, Int_val); // 更新 x

    } else {
        // 更新 y，x 保持不动
        double Int1 = 0.0, Int2 = 0.0;
        
        // Int1 计算（y 方向积分）
        for (int i = 1; i < T; ++i) {
            double term1 = f(x_prev, y_prev - i*DELTA);
            double term2 = f(x_prev, y_prev + i*DELTA);
            if (term1 != 0.0) Int1 += DELTA * term1;
            if (term2 != 0.0) Int1 -= DELTA * term2;
        }

        // Int2 计算（y 方向二阶项）
        for (int i = -10; i <= 10; ++i) {
            double yi = y_prev + i*DELTA/10.0;
            if (yi >= -0.2 && yi <= 1.6) {
                Int2 += (i * DELTA * f(x_prev, yi)) / 100.0;
            }
        }

        Int_val = Int1 - Int2;
        y_prev -= DELTA * copysign(1.0, Int_val); // 更新 y
    }

    Result res;
    res.x = x_prev;
    res.y = y_prev;
    return res;
}

// 主函数
int main() {
    const int K = 100;       // 总迭代次数
    double x = -0.4;         // 初始 x
    double y = -0.3;         // 初始 y

    // 逐步迭代更新
    for (int t = 1; t <= K; t++) {
        // 根据 t 的奇偶性决定更新 x 或 y
        Result result = run_simulation_step(x, y, 50, 0.01, custom_f, (t % 2 == 0));
        x = result.x;
        y = result.y;
        printf("Step %d: x = %.4f, y = %.4f\n", t, x, y);
    }

    printf("\nFinal result after %d steps:\nx = %.4f\ny = %.4f\n", K, x, y);
    return 0;
}
