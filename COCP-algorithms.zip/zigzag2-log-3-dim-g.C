#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <random>
#include <array>
#include <cmath>

//#define PI 3.14159265358979323846
#define DELTA1 0.01    // 固定步长
#define NUM_DIRECTIONS 200  // 随机方向数量
#define T_ITER 250         // 一维搜索迭代次数
#define K 50          // 总步数

// 定义目标函数 f(x, y, N)
double f(double x, double y, double z, int N) {
    double term1 = -log(pow(x - 0.5, 2) + pow(y - 0.5, 2) + pow(z - 0.5, 2) + 0.0001);
    double term2 = -log(pow(x + 0.5, 2) + pow(y + 0.5, 2) + pow(z + 0.5, 2) + 0.1);
    //double term3 = -log(pow(x - 0.5, 2) + pow(y + 0.5, 2) + pow(z - 0.5, 2) + 0.01);
    //double term4 = -log(pow(x + 0.5, 2) + pow(y - 0.5, 2) + pow(z - 0.5, 2) + 0.01);
    return pow(fmax(0.0, term1 + term2), N);
}

// Generate random unit v on S^2 using Gaussian method

std::array<double, 3> sample_unit_vector_gaussian_R3() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::normal_distribution<double> dist(0.0, 1.0);
    
    std::array<double, 3> v;
    double norm_squared = 0.0;
    
    // Generate 3 independent Gaussian random variables
    for (int i = 0; i < 3; ++i) {
        v[i] = dist(gen);
        norm_squared += v[i] * v[i];
    }
    
    // Normalize to get a point on the unit sphere
    double norm = std::sqrt(norm_squared);
    for (int i = 0; i < 3; ++i) {
        v[i] /= norm;
    }
    
    return v;
}

// 计算沿方向 v 的差值
double compute_difference(double x, double y, double z, double v_x, double v_y, double v_z, double r_t, int N) {
    double f_plus = f(x + r_t * v_x, y + r_t * v_y, z + r_t * v_z, N);
    double f_minus = f(x - r_t * v_x, y - r_t * v_y, z - r_t * v_z, N);
    return f_plus - f_minus;
}

// 沿方向 v 进行一维搜索，返回最优步长 s
double compute_s_along_v(double x, double y, double z, double v_x, double v_y, double v_z, int N, int T_iter, double DELTA) {
    double s_t = 0.0;
    double Int1 = 0.0, Int2 = 0.0, Int3 = 0.0, Int = 0.0;

    auto f_s = [&](double s) { return f(x + s * v_x, y + s * v_y, z + s * v_z, N); };

    for (int i = 1; i < T_iter; ++i) {
        double term1 = f_s(s_t - i * DELTA);
        double term2 = f_s(s_t + i * DELTA);
        if (term1 != 0.0) Int1 += DELTA * term1;
        if (term2 != 0.0) Int1 -= DELTA * term2;
    }

    for (int i = -10; i <= 10; ++i) {
        double si = i * DELTA / 10.0;
        Int2 += (i * DELTA * f_s(s_t + si)) / 100.0;
    }

    Int = Int1 - Int2;

    for (int t = 0; t <= T_iter; ++t) {
        double y = s_t;
        s_t -= DELTA * copysign(1.0, Int);

        Int1 = 0.0;
        for (int i = 1; i <= 10; ++i) {
            double si = s_t + DELTA + i * DELTA / 10.0;
            double yi = y - DELTA + i * DELTA / 10.0;
            Int1 += copysign(1.0, Int) * DELTA / 10.0 * f_s(si) +
                    copysign(1.0, Int) * DELTA / 10.0 * f_s(yi);
        }

        Int3 = Int2;
        Int2 = 0.0;
        for (int i = -10; i <= 10; ++i) {
            double shifted_s = s_t + i * DELTA / 10.0;
            Int2 += (i * DELTA * f_s(shifted_s)) / 100.0;
        }

        Int = Int - Int1 - Int2 + Int3;
    }

    return s_t;
}

// 单步更新 (x_t, y_t)
void update_x_y_z_t(double* x_t, double* y_t, double* z_t, double r_t, int N, int T_iter, double DELTA) {
    double max_diff = -1.0;
    double best_v_x = 0.0, best_v_y = 0.0, best_v_z = 0.0;
    double v[3];
    for (int i = 0; i < NUM_DIRECTIONS; ++i) {
        auto rnd = sample_unit_vector_gaussian_R3();
        for (int i = 0; i < 3; ++i){
        v[i] = rnd[i];}
        double diff = compute_difference(*x_t, *y_t, *z_t, v[0], v[1], v[2], r_t, N);
        if (diff > max_diff) {
            max_diff = diff;
            best_v_x = v[0];
            best_v_y = v[1];
            best_v_z = v[2];
        }
    }

    double s = compute_s_along_v(*x_t, *y_t, *z_t, best_v_x, best_v_y, best_v_z, N, T_iter, DELTA);
  
    if (fabs(s) >= (50) * DELTA){
      *x_t += 10 * DELTA * best_v_x;
    *y_t += 10 * DELTA * best_v_y;
    *z_t += 10 * DELTA * best_v_z;
    }
    else {*x_t += s * best_v_x;
    *y_t += s * best_v_y;
    *z_t += s * best_v_z;}
}

// 主函数
int main() {
    srand(time(NULL));

    int N = 5;
    double x_t = -0.1;
    double y_t = 0;
    double z_t = 0; 
    double r_t = 1;

    printf("Initial: x_t = %f, y_t = %f, z_t = %f, r_t = %f\n", x_t, y_t, z_t, r_t);

    for (int t = 1; t <= K; ++t) {
        //double x=x_t; double y=y_t; double z=z_t;                                
        update_x_y_z_t(&x_t, &y_t, &z_t, r_t, N, T_ITER-T_ITER/K * t+10, DELTA1);
        r_t = fmax(0.01, 1.0 - (1.0 - 0.01)/K * t);  // Linear decrease to 0.01
        printf("Step %d: x_t = %f, y_t = %f, z_t = %f, r_t = %f\n", t, x_t, y_t, z_t, r_t);
    }

    //printf("Final value after %d steps: x_t = %f, y_t = %f, z_t = %f, r_t = %f\n", K, x_t, y_t, z_t, r_t);

    return 0;
}
