#include <stdio.h>
#include <math.h>

#define N 4 // Define a dim value for N
#define NP 11 // Define a value of power
#define K 2 // Example value for K, adjust accordingly
#define DELTA 0.02 // Example value for delta, adjust accordingly
#define DELTA1 0.2 // Differential gap for Int_1
#define T 100 //No. of steps of gradient descent
// Define the test function f

double f(double *x) {double term1=3.0; //term2=0.0, term3=0.0, term4=0.0;
    // Example: f(x) =1.5-100(y-x^2)^2-(1-x)^2
    
    //double result=-100*(x[1]-x[0]*x[0])*(x[1]-x[0]*x[0])
    //-(1-x[0])*(1-x[0])+1.5;
    //if (result>0){return pow(result,NP);}
    //else{return 0.0;}
  
  //double result=-100*(x[1]-x[0]*x[0])*(x[1]-x[0]*x[0])
    //-(1-x[0])*(1-x[0])+1.5;
    //if (result>0){return pow(result,NP);}
    //else{return 0.0;}
  for (int i=0; i<N/2; i++){
  term1 -= 100*pow((x[2*i]*x[2*i]-x[2*i+1]), 2) + pow(x[2*i]-1, 2);}
    //term2 += pow(x[i] + 0.5, 2);
    //term3 += pow(x[i] + pow(-1, i) * 0.5, 2);
    //term4 += pow(x[i] + pow(-1, i+1) * 0.5, 2);}
  
  //double term1 = -log(pow(x[0] - 0.5, 2) + pow(x[1] - 0.5, 2) + pow(x[2] - 0.5, 2) + 0.0001);
    //double term2 = -log(pow(x[0] + 0.5, 2) + pow(x[1] + 0.5, 2) + pow(x[2] + 0.5, 2) + 0.1);
    //double term3 = -log(pow(x - 0.5, 2) + pow(y + 0.5, 2) + pow(z - 0.5, 2) + 0.01);
    //double term4 = -log(pow(x + 0.5, 2) + pow(y - 0.5, 2) + pow(z - 0.5, 2) + 0.01);
    //return pow(fmax(0.0, term1 + term2), N);
    //return pow(fmax(0.0, -log(term1 + 0.0001) - log(term2 + 0.01) - log(term3 + 0.01) - log(term4 + 0.01)), NP);
    if (term1>0){return pow(term1,NP);}
    else{return 0.0;}
}
                    

//Euclidean norm for Int_1

double norm(double *x, double *y) {
    double sum = 0.0;
    for (int i = 0; i < N; i++) {
        sum += (x[i] - y[i]) * (x[i] - y[i]);
    }
    return sqrt(sum);
}

// Calculate the integrand (x_i - y_i)*f(y)/||x - y|| for Int_1

double integrand1(double *x, double *y, int i) {
       int sign = (x[i] - y[i] > 0) ? 1 : -1;
    double norm_val = norm(x, y);
    if (norm_val-fabs(x[i] - y[i])<DELTA1)
    {return sign*f(y);}
    else {
        return (x[i] - y[i]) * f(y) / norm_val;
         }
}

// Calculate the integrand (x_i - y_i) * f(y) for Int_2

double integrand2(double *x, double *y, int i) {
    
        return (x[i] - y[i]) * f(y);
}

// Integrate (x_i - y_i) * f(y) / ||x - y|| for Int_1

double integrate1(double *x, int i) {
    double result = 0.0;
    
    // Iterate over all combinations of y in [-K, K]^2 (since N=2)
    // For simplicity, we will sample values in a grid within [-K, K]
    
    int steps=(int)(K/DELTA1);
    
    // Number of grid points per dimension
    
    double y[N];
    int j[N];

    // Loop through the grid for each dimension (2D)
  //for (int j=0; j< N; j++){
    for (j[0] = -steps; j[0] <= steps; j[0]++) {
        for (j[1] = -steps; j[1] <= steps; j[1]++) {
          for (j[2]=-steps; j[2]<= steps; j[2]++){
            for (j[3]=-steps; j[3]<= steps; j[3]++) {
            // Populate y with current grid points
            //y[j]=i[j] * DELTA1;
            y[0] = j[0] * DELTA1;
            y[1] = j[1] * DELTA1;
            y[2] = j[2] * DELTA1;
            y[3] = j[3] * DELTA1;
                
            result += integrand1(x, y, i) * pow(DELTA1, N);    // Multiply by volume element
        //}
    }
        }
        }
  }
    return result;
}

//Integrate (x_i - y_i) * f(y) for Int_2

double integrate2(double *x, int i) {
    double result = 0.0;
    double y[N];
    int j[N];
    for (j[0] = -10; j[0] <= 10; j[0]++) {
        for (j[1] = -10; j[1] <= 10; j[1]++) {
            //Differential gap $\delta/10$
          for (j[2] = -10; j[2] <= 10; j[2]++){ 
            for (j[3] = -10; j[3] <= 10; j[3]++){
            y[0] = x[0]+j[0] * DELTA/10.0;
            y[1] = x[1]+j[1] * DELTA/10.0;
            y[2] = x[2]+j[2] * DELTA/10.0;
            y[3] = x[3]+j[3] * DELTA/10.0;

            // Evaluate the integrand for each dimension
  
                result += integrand2(x, y, i)* pow(DELTA, N-1)/pow(10.0, N); // Multiply by volume element
            }
          }
        }
    }
    return result;
}

// Function to compute Int_1 for a given vector x
void compute_Int_1(double *x, double *Int_1) {
    // Initialize Int_1 to zero
    
    for (int i = 0; i < N; i++) {
        Int_1[i] = 0.0;
    // Compute the sum for Int_1
    
        Int_1[i] = integrate1(x, i);  // scale by 10^n
    }
}

// Function to compute Int_2 for a given vector x

void compute_Int_2(double *x, double *Int_2) {
    // Initialize Int_2 to zero
    
    for (int i = 0; i < N; i++) {
        Int_2[i] = 0.0;
    }
    // Compute the sum for Int_2
    
    for (int i = 0; i < N; i++) {
        Int_2[i] = integrate2(x, i); 
    }
}

// Function to update vector x based on Int_1 and Int_2

void update_x(double *x, double *Int_1, double *Int_2) {
    int sign[N];//array of signs of partial gradients
    
    for (int i = 0; i < N; i++) {
        if (Int_1[i]-Int_2[i] >=DELTA/5.0) 
        {sign[i]=1;}
        else if(Int_1[i]-Int_2[i] <=-DELTA/5.0)
        {sign[i]=-1;}
        else {sign[i]=0;} 
        }
        for (int i=0; i<N; i++){
            x[i] -= DELTA * sign[i];  // Update x with the gradient step
            }
}// sign function

int main() {
    // Initialize vector x to zeros (x0)
    double x[N] = {-1.0, 1, 1, 1};
    
    double Int_1[N], Int_2[N];
    
    // Compute initial values of Int_1 and Int_2
    
    compute_Int_1(x, Int_1);
    compute_Int_2(x, Int_2);

    // Iterative loop (while t <= T)
    for (int t = 0; t < T; t++) {
        // Update x based on Int_1 and Int_2
        update_x(x, Int_1, Int_2);

        // Recompute Int_1 and Int_2 at the new x
        
        compute_Int_1(x, Int_1);
        compute_Int_2(x, Int_2);

        // Output the updated x after each iteration
        
        printf("Iteration %d, x = [", t);
        for (int i = 0; i < N; i++) {
            printf("%f, ", x[i]);
        }
        
        // Output the updated partial derivatives after each iteration
        
        //for (int i = 0; i < N; i++) {
            //printf("%f, ", Int_1[i]-Int_2[i]);
        //}
        printf("]\n");
     }
     return 0;
}