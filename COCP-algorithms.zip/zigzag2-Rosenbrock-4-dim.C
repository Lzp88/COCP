#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <random>
#include <array>
#include <functional>


#define N 15 // Define a value of power
//#define PI 3.14159265358979323846
#define DELTA1 0.01    // 固定步长
#define SCALE 40     //May need to use smaller scale for integral in COCP1, especially for Rosenbrock with steep climbs
#define NUM_DIRECTIONS 20000 // 随机方向数量
//#define T_ITER 250         // 一维搜索迭代次数
#define K 100          // 总步数
#define RANGE 4          // 总步数

// 定义目标函数 f(x, y, N)
double f(double x, double y, double z, double w, int NP) {
    
  double result=4-100*pow(x*x-y, 2)-pow(x-1, 2)-100*pow(z*z-w, 2)-pow(z-1, 2);
    if (result>0){return pow(result,NP);}
    else{return 0.0;}
}

// 辛普森1/3法则 (Simpson's 1/3 Rule)
double simpson_13(std::function<double(double)> func, double a, double b, int n) {
  if (a > b) {
        return -simpson_13(func, b, a, n);
    }
    // n必须是偶数
    if (n % 2 != 0) {
        n++; // 如果不是偶数，加1使其变为偶数
    }
    
    double h = (b - a) / n;
    double sum = func(a) + func(b); // 首尾项
    
    // 奇数项系数为4，偶数项系数为2
    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        if (i % 2 == 0) {
            sum += 2 * func(x);
        } else {
            sum += 4 * func(x);
        }
    }
    
    return sum * h / 3.0;
}

// 辛普森3/8法则 (Simpson's 3/8 Rule)
double simpson_38(std::function<double(double)> func, double a, double b, int n) {
  if (a > b) {
        return -simpson_38(func, b, a, n);
    }
    // n必须是3的倍数
    if (n % 3 != 0) {
        n = ((n / 3) + 1) * 3; // 调整到最近的3的倍数
    }
    
    double h = (b - a) / n;
    double sum = func(a) + func(b); // 首尾项
    
    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        if (i % 3 == 0) {
            sum += 2 * func(x);
        } else {
            sum += 3 * func(x);
        }
    }
    
    return sum * h * 3.0 / 8.0;
}

// Generate unit v in R^4 using Gaussian sampling
std::array<double, 4> sample_unit_vector() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::normal_distribution<double> dist(0.0, 1.0);

    std::array<double, 4> v;
    double norm_squared = 0.0;

    // Generate random Gaussian components and compute squared norm
    for (int i = 0; i < 4; ++i) {
        v[i] = dist(gen);
        norm_squared += v[i] * v[i];
    }

    // Normalize the vector to unit length
    double norm = std::sqrt(norm_squared);
    for (int i = 0; i < 4; ++i) {
        v[i] /= norm;
    }

    return v;
}

// 计算沿方向 v 的差值
double compute_difference(double x, double y, double z, double w, double v_x, double v_y, double v_z, double v_w, double r_t, int NP) {
    double f_plus = f(x + r_t * v_x, y + r_t * v_y, z + r_t * v_z, w + r_t * v_w, NP);
    double f_minus = f(x - r_t * v_x, y - r_t * v_y, z - r_t * v_z, w - r_t * v_w, NP);
    return f_plus - f_minus;
}

// 沿方向 v 进行一维搜索，返回最优步长 s
double compute_s_along_v(double x, double y, double z, double w, double v_x, double v_y, double v_z, double v_w, int NP, int T_iter, double DELTA) {
    double s_t = 0.0;
    double Int1 = 0.0, Int2 = 0.0, Int3 = 0.0, Int = 0.0;

    auto f_s = [&](double s) { double raw = 4.0 - 100*pow((x+s*v_x)*(x+s*v_x) - (y+s*v_y), 2)
                 - pow((x+s*v_x)-1,2)
                 - 100*pow((z+s*v_z)*(z+s*v_z) - (w+s*v_w),2)
                 - pow((z+s*v_z)-1,2);
double smooth_gate = 1.0 / (1.0 + exp(-1.0 * raw)); // β=5，可调
return smooth_gate * f(x + s*v_x, y + s*v_y, z + s*v_z, w + s*v_w, NP);
      //return f(x + s * v_x, y + s * v_y, z + s * v_z, w + s * v_w, NP); 
    };
    auto f_s_s = [&](double s) { return s * f_s(s); };

    Int1 = simpson_13(f_s, -RANGE, -DELTA, RANGE/DELTA) - simpson_13(f_s, DELTA, RANGE, RANGE/DELTA);
  
    Int2 = simpson_13(f_s_s, -DELTA, DELTA, SCALE) / DELTA;

    Int = Int1 - Int2;

    for (int t = 0; t < RANGE / DELTA1; ++t) {
        double y = s_t;
        s_t -= DELTA * copysign(1.0, Int);

        Int1 = simpson_13(f_s, y-DELTA, s_t-DELTA, SCALE) + simpson_13(f_s, y+DELTA, s_t+DELTA, SCALE); 

        Int3 = Int2;
      
        Int2 = (simpson_13(f_s_s, s_t-DELTA, s_t+DELTA, SCALE)- s_t * simpson_13(f_s, s_t-DELTA, s_t+DELTA, SCALE))/ DELTA ;
      
        Int -= Int1 + Int2 - Int3;
    }

    return s_t;
}

// 单步更新 (x_t, y_t)
void update_x_y_z_t(double* x_t, double* y_t, double* z_t, double* w_t, double r_t, int NP, int T_iter, double DELTA) {
    double max_diff = -1.0;
    double best_v_x = 0.0, best_v_y = 0.0, best_v_z = 0.0, best_v_w = 0.0;
    double v[4];
    for (int i = 0; i < NUM_DIRECTIONS; ++i) {
        auto rnd = sample_unit_vector();
        for (int i = 0; i < 4; ++i){
        v[i] = rnd[i];}
        double diff = compute_difference(*x_t, *y_t, *z_t, *w_t, v[0], v[1], v[2], v[3], r_t, NP);
        if (diff > max_diff && diff>DELTA/2.0) {
            max_diff = diff;
            best_v_x = v[0];
            best_v_y = v[1];
            best_v_z = v[2];
            best_v_w = v[3];
        }
      
    }

    double s = compute_s_along_v(*x_t, *y_t, *z_t, *w_t, best_v_x, best_v_y, best_v_z, best_v_w, NP, T_iter, DELTA);
  
    if (fabs(s) >= (20) * DELTA){
      *x_t += 10 * DELTA * best_v_x;
    *y_t += 10 * DELTA * best_v_y;
    *z_t += 10 * DELTA * best_v_z;
    *w_t += 10 * DELTA * best_v_w;
    }
    else {*x_t += fmin(DELTA, fabs(s)) *copysign(1.0, s) * best_v_x;
    *y_t += fmin(DELTA, fabs(s)) *copysign(1.0, s)* best_v_y;
    *z_t += fmin(DELTA, fabs(s)) *copysign(1.0, s)* best_v_z;
    *w_t += fmin(DELTA, fabs(s)) *copysign(1.0, s)* best_v_w;}
}

// 主函数
int main() {
    srand(time(NULL)); 
    double x_t = -1.0;
    double y_t = 0;
    double z_t = 1; 
    double w_t = 1;
    double r_t = 1.0;

    printf("Initial: x_t = %f, y_t = %f, z_t = %f, w_t = %f, r_t = %f\n", x_t, y_t, z_t, w_t, r_t);

    for (int t = 1; t <= K; ++t) {                               
        update_x_y_z_t(&x_t, &y_t, &z_t, &w_t, r_t, N, RANGE/DELTA1-RANGE/(DELTA1*K) * t+1, DELTA1);
        r_t = fmax(DELTA1, 1.0 - (1.0 - DELTA1)/K * t);  // Linear decrease to 0.01
        printf("Step %d: x_t = %f, y_t = %f, z_t = %f, w_t = %f, r_t = %f\n", t, x_t, y_t, z_t, w_t, r_t);
    }

    //printf("Final value after %d steps: x_t = %f, y_t = %f, z_t = %f, r_t = %f\n", K, x_t, y_t, z_t, r_t);

    return 0;
}
