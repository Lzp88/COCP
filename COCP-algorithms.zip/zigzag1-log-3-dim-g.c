// Online C compiler to run C program online
#include <stdio.h>
#include <math.h>

// 二元函数 f(x, y)
double f(double x, double y, double z) {
    double term1 = -log(pow(x - 0.5, 2) + pow(y - 0.5, 2) + pow(z - 0.5, 2)+0.00001);
    double term2 = -log(pow(x + 0.5, 2) + pow(y + 0.5, 2) +pow(z + 0.5, 2) + 0.01);
    double term3 = -log(pow(x - 0.25, 2) + pow(y + 0.25, 2) +pow(z + 0.25, 2) + 0.001);
    return fmax(0.0, term1 + term2+term3); // 使用 fmax 实现 max{0, ·}
}

// 计算 x_t 和 y_t 的函数，根据 t 的奇偶性更新 x 或 y
void compute_x_y_z_t(int N, int T, double DELTA, int t, double initial_x, double initial_y, double initial_z, double* x_t, double* y_t, double* z_t) {
    *x_t = initial_x; // 使用传入的 initial_x 初始化 x_t
    *y_t = initial_y; // 使用传入的 initial_y 初始化 y_t
    *z_t = initial_z;

    // 根据 t 的奇偶性决定更新 x 还是 y
    int direction = (t % 3);
    double* var_to_update = (direction == 0) ? z_t : (direction-1 ? y_t : x_t); // 指向要更新的变量

    double Int1 = 0.0, Int2 = 0.0, Int3 = 0.0, Int = 0.0;

    // 计算 Int1
    for (int i = 1; i < T; ++i) {
        double term1, term2;
        if (direction == 0) {
            term1 = f(*x_t, *y_t, *z_t - i * DELTA);
            term2 = f(*x_t, *y_t, *z_t + i * DELTA);
        } else if (direction == 1){
            term1 = f(*x_t - i * DELTA, *y_t, *z_t);
            term2 = f(*x_t + i * DELTA, *y_t, *z_t);
        }
         else {
            term1 = f(*x_t, *y_t - i * DELTA, *z_t);
            term2 = f(*x_t, *y_t + i * DELTA, *z_t);
         }
        if (term1 != 0.0) Int1 += DELTA * pow(term1, N);
        if (term2 != 0.0) Int1 -= DELTA * pow(term2, N);
    }

    // 计算 Int2
    for (int i = -10; i <= 10; ++i) {
        double xi = i * DELTA / 10.0;
        double f_val;
        f_val=(direction == 0) ? f(*x_t, *y_t, *z_t+xi): (direction-1 ? f(*x_t, *y_t+xi, *z_t) : f(*x_t+xi, *y_t, *z_t));
        Int2 += (i * DELTA * pow(f_val, N)) / 100.0;
    }

    Int = Int1 - Int2;

    // 迭代更新
    for (int iter = 0; iter <= T; ++iter) {
        double prev_var = *var_to_update;
        *var_to_update -= DELTA * copysign(1.0, Int);

        // 更新 Int1
        Int1 = 0.0;
        for (int i = 1; i <= 10; ++i) {
            double xi, yi, zi;
            if (direction == 1) {
                xi = *x_t + DELTA + i * DELTA / 10.0;
                yi = *y_t;
                zi = *z_t;
                double prev_xi = prev_var - DELTA + i * DELTA / 10.0;
                Int1 += copysign(1.0, Int) * DELTA / 10.0 * pow(f(xi, *y_t, *z_t), N) +
                        copysign(1.0, Int) * DELTA / 10.0 * pow(f(prev_xi, *y_t, *z_t), N);
            } else if (direction == 2) {
                xi = *x_t;
                yi = *y_t + DELTA + i * DELTA / 10.0;
                zi = *z_t;
                double prev_yi = prev_var - DELTA + i * DELTA / 10.0;
                Int1 += copysign(1.0, Int) * DELTA / 10.0 * pow(f(*x_t, yi, *z_t), N) +
                        copysign(1.0, Int) * DELTA / 10.0 * pow(f(*x_t, prev_yi, *z_t), N);
            }
          else {
                xi = *x_t;
                yi = *y_t;
                zi = *z_t + DELTA + i * DELTA / 10.0;
                double prev_zi = prev_var - DELTA + i * DELTA / 10.0;
                Int1 += copysign(1.0, Int) * DELTA / 10.0 * pow(f(*x_t, *y_t, zi), N) +
                        copysign(1.0, Int) * DELTA / 10.0 * pow(f(*x_t, *y_t, prev_zi), N);
          }
        }

        // 更新 Int3 和 Int2
        Int3 = Int2;
        Int2 = 0.0;
        for (int i = -10; i <= 10; ++i) {
            double shifted_var = *var_to_update + i * DELTA / 10.0;
            double f_val;
            if (direction ==1) {
                f_val = f(shifted_var, *y_t, *z_t);
            } else if (direction ==2) {
                f_val = f(*x_t, shifted_var, *z_t);
            }
          else {
            f_val = f(*x_t, *y_t, shifted_var);
          }
            Int2 += (i * DELTA * pow(f_val, N)) / 100.0;
        }

        // 更新 Int
        Int = Int - Int1 - Int2 + Int3;
    }
}

// 主函数
int main() {
    int N = 4;          // 幂次（当前未使用，可扩展）
    int T = 20;        // 迭代次数
    double DELTA = 0.01; // 步长
    int K = 80;         // 循环次数

    double x_t = 0.44;   // 初始 x_t
    double y_t = 0.15;   // 初始 y_t
    double z_t = 0.3;

    // 对 t 进行循环，从 1 到 K
    for (int t = 1; t <= K; ++t) {
        double temp_x, temp_y, temp_z;
        compute_x_y_z_t(N, T, DELTA, t, x_t, y_t, z_t, &temp_x, &temp_y, &temp_z);
        x_t = temp_x;  // 更新 x_t 为本次计算结果
        y_t = temp_y;  // 更新 y_t 为本次计算结果
        z_t = temp_z; 
        printf("Final value after %d updates: x_t = %f, y_t = %f, z_t = %f\n", t, x_t, y_t, z_t);

    }

    // 输出 K 次更新后的最终值
    
    return 0;
}
