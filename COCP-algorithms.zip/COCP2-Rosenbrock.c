#include <stdio.h>
#include <math.h>

#define N 2 // Define a value for N
#define NP 7 // Define a value of power
#define K 1.5 // Example value for K, adjust accordingly
#define DELTA 0.01 // Example value for delta, adjust accordingly
#define DELTA1 0.2 // Differential gap for Int_1
#define T 250 //No. of updates
// Define the test function f

double f(double *x) {
    // Example: f(x) =1.5-100(y-x^2)^2-(1-x)^2
    
    double result=-100*(x[1]-x[0]*x[0])*(x[1]-x[0]*x[0])
    -(1-x[0])*(1-x[0])+1.5;
    if (result>0){return pow(result,NP);}
    else{return 0.0;}
}

//Euclidean norm for Int_1

double norm(double *x, double *y) {
    double sum = 0.0;
    for (int i = 0; i < N; i++) {
        sum += (x[i] - y[i]) * (x[i] - y[i]);
    }
    return sqrt(sum);
}

// Calculate the integrand (x_i - y_i)*f(y)/||x - y|| for Int_1

double integrand1(double *x, double *y, int i) {
       int sign = (x[i] - y[i] > 0) ? 1 : -1;
    double norm_val = norm(x, y);
    int j=1-i;
    if (fabs(x[j]-y[j])<DELTA1)
    {return sign*f(y);}
    else {
        return (x[i] - y[i]) * f(y) / norm_val;
         }
}

// Calculate the integrand (x_i - y_i) * f(y) for Int_2

double integrand2(double *x, double *y, int i) {
    
        return (x[i] - y[i]) * f(y);
}

// Integrate (x_i - y_i) * f(y) / ||x - y|| for Int_1

double integrate1(double *x, int i) {
    double result = 0.0;
    
    // Iterate over all combinations of y in [-K, K]^2 (since N=2)
    // For simplicity, we will sample values in a grid within [-K, K]
    
    int steps=(int)(K/DELTA1);
    
    // Number of grid points per dimension
    
    double y[N];

    // Loop through the grid for each dimension (2D)
    for (int i1 = -steps; i1 <= steps; i1++) {
        for (int i2 = -steps; i2 <= steps; i2++) {
            // Populate y with current grid points
            
            y[0] = i1 * DELTA1;
            y[1] = i2 * DELTA1;
                result += integrand1(x, y, i) * DELTA1 * DELTA1; 
                // Multiply by volume element
        }
    }
    return result;
}

//Integrate (x_i - y_i) * f(y) for Int_2

double integrate2(double *x, int i) {
    double result = 0.0;
    double y[N];
    for (int i1 = -10; i1 <= 10; i1++) {
        for (int i2 = -10; i2 <= 10; i2++) {
            //Differential gap $\delta/10$
            
            y[0] = x[0]+i1 * DELTA/10.0;
            y[1] = x[1]+i2 * DELTA/10.0;

            // Evaluate the integrand for each dimension
  
                result += integrand2(x, y, i)* DELTA/100.0; // Multiply by volume element
            }
    }
    return result;
}

// Function to compute Int_1 for a given vector x
void compute_Int_1(double *x, double *Int_1) {
    // Initialize Int_1 to zero
    
    for (int i = 0; i < N; i++) {
        Int_1[i] = 0.0;
    // Compute the sum for Int_1
    
        Int_1[i] = integrate1(x, i);  // scale by 10^n
    }
}

// Function to compute Int_2 for a given vector x

void compute_Int_2(double *x, double *Int_2) {
    // Initialize Int_2 to zero
    
    for (int i = 0; i < N; i++) {
        Int_2[i] = 0.0;
    }
    // Compute the sum for Int_2
    
    for (int i = 0; i < N; i++) {
        Int_2[i] = integrate2(x, i); 
    }
}

// Function to update vector x based on Int_1 and Int_2

void update_x(double *x, double *Int_1, double *Int_2) {
    int sign[N];//array of signs of partial gradients
    
    for (int i = 0; i < N; i++) {
        if (Int_1[i]-Int_2[i] >=DELTA/10.0) 
        {sign[i]=1;}
        else if(Int_1[i]-Int_2[i] <=-DELTA/10.0)
        {sign[i]=-1;}
        else {sign[i]=0;} 
        }
        for (int i=0; i<N; i++){
            x[i] -= DELTA * sign[i];  // Update x with the gradient step
            }
}// sign function

int main() {
    // Initialize vector x to zeros (x0)
    double x[N] = {-1.2,-1.3};
    
    double Int_1[N], Int_2[N];
    
    // Compute initial values of Int_1 and Int_2
    
    compute_Int_1(x, Int_1);
    compute_Int_2(x, Int_2);

    // Iterative loop (while t <= T)
    for (int t = 0; t < T; t++) {
        // Update x based on Int_1 and Int_2
        update_x(x, Int_1, Int_2);

        // Recompute Int_1 and Int_2 at the new x
        
        compute_Int_1(x, Int_1);
        compute_Int_2(x, Int_2);

        // Output the updated x after each iteration
        
        printf("Iteration %d, x = [", t);
        for (int i = 0; i < N; i++) {
            printf("%f, ", x[i]);
        }
        
        // Output the updated partial derivatives after each iteration
        
        for (int i = 0; i < N; i++) {
            printf("%f, ", Int_1[i]-Int_2[i]);
        }
        printf("]\n");
     }
     return 0;
}